#ifndef JOS_INC_MALLOC_H
#define JOS_INC_MALLOC_H 1

#include <inc/types.h>

void *malloc(size_t size);
void free(void *addr);

#endif
