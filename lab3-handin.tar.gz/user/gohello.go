package main

import "sys"

func main() {
	sys.Println("hello, go")
}
